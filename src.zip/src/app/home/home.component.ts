import { Component } from '@angular/core';

@Component({
	selector: 'home',
	templateUrl: './home.component.html',
	styleUrls: []
})
export class HomeComponent {
  title = 'home';
}

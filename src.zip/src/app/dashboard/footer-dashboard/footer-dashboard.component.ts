import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer-dashboard',
  templateUrl: './footer-dashboard.component.html',
  styleUrls: ['./footer-dashboard.component.css']
})
export class FooterDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-leftnav-dashboard',
  templateUrl: './leftnav-dashboard.component.html',
  styleUrls: ['./leftnav-dashboard.component.css']
})
export class LeftnavDashboardComponent {

}
